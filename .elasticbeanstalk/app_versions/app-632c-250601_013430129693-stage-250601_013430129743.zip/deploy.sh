./build.sh
eb deploy --staged --profile bia